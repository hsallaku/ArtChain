package network;
import java.util.*;

public class Node {
    private int id;
    private Network network;
    private List<String> messages;
    
    public Node(int id, Network network) {
        this.id = id;
        this.network = network;
        messages = new ArrayList<>();
    }
    
    public void receiveMessage(int senderId, String message) {
        System.out.printf("Node %d received message '%s' from node %d\n", id, message, senderId);
        messages.add(message);
    }
    
    public void startNode() {
        while(true) {
            try {
                Thread.sleep(1000);
            }
            catch(InterruptedException e) {
                e.printStackTrace();
            }
            
            if(Math.random() < 0.5) {
                int receiverId = (int) (Math.random() * network.nodes.size());
                if(receiverId != id) {
                    String message = String.format("Hello from node %d!", id);
                    network.sendMessage(id, receiverId, message);
                }
            }
        }
    }
}
