package network;
import java.util.*;

public class Network {
    public Map<Integer, Node> nodes;
    
    public Network(int n) {
        nodes = new HashMap<>();
        for(int i = 0; i < n; i++) {
            nodes.put(i, new Node(i, this));
        }
    }
    
    public void startNetwork() {
        for(Node node : nodes.values()) {
            node.startNode();
        }
    }
    
    public void sendMessage(int senderId, int receiverId, String message) {
        Node receiver = nodes.get(receiverId);
        receiver.receiveMessage(senderId, message);
    }
}